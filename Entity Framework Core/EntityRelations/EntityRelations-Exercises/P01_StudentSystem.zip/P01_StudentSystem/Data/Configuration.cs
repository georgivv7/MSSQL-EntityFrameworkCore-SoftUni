﻿namespace P01_StudentSystem.Data
{
    internal class Configuration
    {
        internal const string ConnectionString = @"Server=DESKTOP-A2E8T9T\SQLEXPRESS;Database=StudentSystem;Integrated Security=True";
    }
}
