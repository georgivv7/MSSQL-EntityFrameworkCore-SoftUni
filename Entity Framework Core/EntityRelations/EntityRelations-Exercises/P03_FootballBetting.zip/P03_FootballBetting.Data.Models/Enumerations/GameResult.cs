﻿namespace P03_FootballBetting.Data.Enumerations
{
    public enum GameResult
    {
        HomeWin=1,
        AwayWin=2,
        Draw=0
    }
}
