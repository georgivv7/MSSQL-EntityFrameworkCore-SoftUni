﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => "Server=DESKTOP-A2E8T9T\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
