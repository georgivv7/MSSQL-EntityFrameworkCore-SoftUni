﻿namespace BookShop.Models.Enums
{
    public enum EditionType
    {
        Normal,
        Promo,
        Gold
    }
}