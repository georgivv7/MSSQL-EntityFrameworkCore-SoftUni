﻿
namespace P03_SalesDatabase.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-A2E8T9T\SQLEXPRESS;Database=Sales;" +
            "Integrated Security=True";
    }
}
