﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-A2E8T9T\SQLEXPRESS;Database=Hospital;" +
            "Integrated Security=True";
    }
}
