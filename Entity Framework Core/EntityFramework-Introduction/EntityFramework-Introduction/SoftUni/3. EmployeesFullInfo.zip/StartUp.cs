﻿using SoftUni.Data;
using SoftUni.Models;
using System;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            SoftUniContext context = new SoftUniContext();
            Console.WriteLine(GetEmployeesFullInformation(context));
        }
        public static string GetEmployeesFullInformation(SoftUniContext softUniContext)
        {
            StringBuilder stringBuilder = new StringBuilder();

            var employees = softUniContext.Employees
                                          .OrderBy(e => e.EmployeeId)
                                          .Select(x => new Employee
                                          {
                                              FirstName = x.FirstName,
                                              LastName = x.LastName,
                                              MiddleName = x.MiddleName,
                                              JobTitle = x.JobTitle,
                                              Salary = x.Salary
                                          })
                                          .ToList();

            foreach (var item in employees)
            {
                stringBuilder.AppendLine(item.FirstName + " " + item.LastName + " " + item.MiddleName
                    + " " + item.JobTitle + " " + $"{item.Salary:f2}");
            }

            return stringBuilder.ToString();
        }
    }
}
