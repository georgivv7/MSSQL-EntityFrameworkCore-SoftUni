﻿namespace Theatre.DataProcessor.ExportDto
{
    public class ExportTicketDto
    {
        public decimal Price { get; set; }  
        public int RowNumber { get; set; }
    }
}
