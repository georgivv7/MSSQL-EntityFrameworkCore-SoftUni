﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-A2E8T9T\SQLEXPRESS;Database=Theatre;Trusted_Connection=True";
    }
}
