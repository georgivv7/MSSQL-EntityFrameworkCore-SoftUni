﻿namespace Artillery.DataProcessor.ImportDto
{
    using System.ComponentModel.DataAnnotations;
    public class ImportCountryGunDto
    {
        [Required]
        public int Id { get; set; } 
    }
}
