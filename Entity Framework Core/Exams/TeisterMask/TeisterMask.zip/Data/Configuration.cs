﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-A2E8T9T\SQLEXPRESS;Database=TeisterMask;Trusted_Connection=True";
    }
}
